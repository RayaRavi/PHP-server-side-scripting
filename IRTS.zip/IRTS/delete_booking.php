<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "lbrce";
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $username = $_POST['delete_username'];
    $stmt = $conn->prepare("DELETE FROM bookings WHERE username = ?");
    $stmt->bind_param("s", $username);
    
    if ($stmt->execute()) {
        header("Location: bookingsview.php?delete=success");
        exit();
    } else {
        header("Location: bookingsview.php?error=sqlerror");
        exit();
    }
} else {
    header("Location: bookingsview.php");
    exit();
}
$stmt->close();
$conn->close();
?>
