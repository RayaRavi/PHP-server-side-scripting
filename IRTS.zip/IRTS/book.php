<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "lbrce";
include("links.html");
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['user_name'];
    $boarding_point = $_POST['boarding_point'];
    $destination = $_POST['destination'];
    $date_of_boarding = $_POST['date_of_boarding'];
    $class_type = $_POST['class_type'];
    if (empty($username) || empty($boarding_point) || empty($destination) || empty($date_of_boarding) || empty($class_type)) {
        header("Location: book.html?error=emptyfields");
        exit();
    } else {
        $stmt = $conn->prepare("INSERT INTO bookings (username, boarding, destination, date, class) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $username, $boarding_point, $destination, $date_of_boarding, $class_type);        
        if ($stmt->execute()) {
            // echo"Booking success";
            header("Location: bookingsview.php");
            exit();
        } else {
            header("Location: book.html?error=sqlerror");
            exit();
        }
    }
} else {
    header("Location: book.html");
    exit();
}
$stmt->close();
$conn->close();
?>
