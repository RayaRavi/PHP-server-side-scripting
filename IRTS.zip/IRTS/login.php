<?php
$admin_username = "Raya";
$admin_password = "Ravi";
$username = $_POST['username'];
$password = $_POST['password'];
if ($username === $admin_username && $password === $admin_password) {
    // Set admin cookie and redirect to admin page
    setcookie("admin", "true", time() + (86400 * 30), "/"); // 30 days
    header("Location: home.html");
    exit();
} else {
    // Set user cookie and redirect to user page
    setcookie("admin", "false", time() + (86400 * 30), "/"); // 30 days
    header("Location: user.html");
    exit();
}
?>
