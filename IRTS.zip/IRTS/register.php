<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "lbrce";
include("links.html");
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    if (empty($username) || empty($password)) {
        header("Location: register.html?error=emptyfields");
        exit();
    } else {
        $stmt = $conn->prepare("INSERT INTO ravi (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $password); 
        if ($stmt->execute()) {
            header("Location: index.html?registration=success");
            exit();
        } else {
            header("Location: register.html?error=sqlerror");
            exit();
        }
    }
} else {
    header("Location: register.html");
    exit();
}
$stmt->close();
$conn->close();
?>
