<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "lbrce";
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST['update'])) {
    $username = $_POST['username'];
    $boarding_point = $_POST['boarding_point'];
    $destination = $_POST['destination'];
    $date_of_boarding = $_POST['date_of_boarding'];
    $class_type = $_POST['class_type'];
    $stmt = $conn->prepare("UPDATE bookings SET boarding = ?, destination = ?, date = ?, class = ? WHERE username = ?");
    $stmt->bind_param("sssss", $boarding_point, $destination, $date_of_boarding, $class_type, $username);
    
    if ($stmt->execute()) {
        header("Location: bookingsview.php?update=success");
        exit();
    } else {
        header("Location: bookingsview.php?error=updatefailed");
        exit();
    }
}
if (isset($_POST['delete'])) {
    $username = $_POST['username'];
    $stmt = $conn->prepare("DELETE FROM bookings WHERE username = ?");
    $stmt->bind_param("s", $username);
    if ($stmt->execute()) {
        header("Location: bookingsview.php?delete=success");
        exit();
    } else {
        header("Location: bookingsview.php?error=deletefailed");
        exit();
    }
}
$conn->close();
?>
