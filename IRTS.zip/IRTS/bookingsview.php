<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookings View</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        
    </style>
</head>
<body>
    <!-- <header>
        <h1>Bookings View</h1>
    </header> -->
    <div class="container">
        <h2>Recent Bookings</h2>
        <center>
        <table border = "7">
            <tr>
                <th>Username</th>
                <th>Boarding Point</th>
                <th>Destination</th>
                <th>Date of Boarding</th>
                <th>Class Type</th>
            </tr>
            <?php
            $host = "localhost";
            $username = "root";
            $password = "";
            $database = "lbrce";
            include("links.html");
            $conn = new mysqli($host, $username, $password, $database);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $stmt = $conn->prepare("SELECT * FROM bookings");
            $stmt->execute();
            $result = $stmt->get_result();
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['username'] . "</td>";
                echo "<td>" . $row['boarding'] . "</td>";
                echo "<td>" . $row['destination'] . "</td>";
                echo "<td>" . $row['date'] . "</td>";
                echo "<td>" . $row['class'] . "</td>";
                echo "</tr>";
            }
            $stmt->close();
            $conn->close();
            ?>
        </table>
        </center>
    </div>
    <footer>
        <p>&copy; 2024 Ticket Booking. All rights reserved.</p>
    </footer>
</body>
</html>
